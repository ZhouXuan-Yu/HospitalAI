# 复现说明

- 数据集：DS-PROJECT-NVAF-DOAC-2026-01-v1
- 输入哈希：fnv1a-5de3f0ed
- 运行标识：RUN-1786359091531
- 输出哈希：fnv1a-9353298d
- 脚本：nvaf_doac_comparative.py 1.0.0
- 软件：Python 固定分析流水线（版本随成果包锁定）
