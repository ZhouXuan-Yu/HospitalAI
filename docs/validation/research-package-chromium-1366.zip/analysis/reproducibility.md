# 复现说明

- 数据集：DS-PROJECT-CAP-2026-01-v1
- 输入哈希：fnv1a-c73e209c
- 运行标识：RUN-1785920190688
- 输出哈希：fnv1a-ae1b8f06
- 脚本：cap-descriptive-flow-statistics 1.0.0
- 软件：HospitalAI fixed-statistics 1.0.0；正式研究须登记 R/Python 版本与锁定依赖
